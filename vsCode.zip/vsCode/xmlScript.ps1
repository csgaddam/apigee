param(
   [string]$swaggerPath,
   [string]$pomPath,
   [string]$newPath
)
#Get swagger title
$X = gc $swaggerPath | ConvertFrom-Json

#$proxyName

#Get the contents of the file from the specified path
[xml]$myXML = Get-Content $pomPath

#set artifactId and name of the pom file
$myXML.project.artifactId = $X.info.title
$myXML.project.name = $X.info.title


#save the xml file in the specified location
$myXML.Save($newPath)

#$error[0] | fl * -force


# -pomPath C:\Users\Chandra_Gaddam\Desktop\pom\pom.xml
# -id PkgTypeByQty
# -name PkgTypeByQty
# .\xmlScript.ps1 -pomPath <common_pom_file_location> -newPath <location_to_store_new_pom_file> -id PkgTypeByQty -name PkgTypeByQty

#  & "C:\Users\Chandra_Gaddam\Desktop\pom\xmlScript.ps1 -pomPath C:\Users\Chandra_Gaddam\Desktop\pom1\pom.xml -newPath C:\Users\Chandra_Gaddam\Desktop\pom2\pom.xml-id PkgTypeByQty -name PkgTypeByQty"

#  & "C:\Users\Chandra_Gaddam\Desktop\pom\xmlScript.ps1 -swaggerPath C:\Users\Chandra_Gaddam\Desktop\vsCode\swaggerDocs\PkgTypeByQty.json -newPath C:\Users\Chandra_Gaddam\Desktop\pom2\pom.xml-id PkgTypeByQty -name PkgTypeByQty"