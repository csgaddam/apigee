 Param
    (
        [string]$Path,
		[string]$name
	)
#Get the contents of the file from the specified path
#[xml]$myXML = Get-Content -Path .\pom.xml
[xml]$myXML = Get-Content $Path

#set artifactId and name of the pom file
$myXML.project.artifactId = $name
$myXML.project.name = $name

$myXML.Save((Resolve-Path "$Path").Path)
