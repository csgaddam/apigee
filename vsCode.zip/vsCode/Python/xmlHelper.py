
"""

xmlHelper CLI

Usage:
    xmlHelper.py -f <xml_element_to_find> -a <xml_element_to_add> <index_location> <xml_file_full_path>
    xmlHelper.py -d <xml_element_to_delete> <xml_file_full_path>
    xmlHelper.py -f <xml_element_to_find> -r <xml_replace_with> <xml_file_full_path>
    xmlHelper.py -f <xml_element_to_find> -s <string> <xml_file_full_path>
    xmlHelper.py -h|--help
    xmlHelper.py -v|--version

Options:
    <xml_element_to_add>     XML element to add, This element will be added to the <xml_element_to_find>, , must be a valid XML element 
                             or it can be a fully qualified file. 
    <xml_element_to_find>    XML element to find in document as XPath for example root/child.
    <xml_element_to_delete>  XML element to be deleteed.
    <xml_replace_with>       XML element content to replace with in document as "<replace_element>value<replace_element>", must be a valid XML element 
                             or it can be a fully qualified file. 

    <xml_file_full_path>     The XML file full path.
    <index_location>         When adding an element, in what possition you need this added? For example, if as fist child then index is 1
    <string>                 Text to be inserted in the XML element xml_element_to_find
    -a                       Add, add this element to the document on find location
    -f                       Find, path of element to find as root/element/child_to_find.
    -d                       Delete, path to xml element to delte as root/element/child_to_delete.
    -h --help                Show this screen.
    -r                       Replace, element to replace with as "<new_element>value<new_element>".
    -s                       Insert the given String literal into the text filed of a given XML element.
    -v --version             Show version.
"""
import os
from docopt import docopt
import xml.etree.ElementTree as ET


############################ Function Definitions ########################################
def locate_element(xml_eleemnt_to_itarate, element_to_locate):
    '''
    Locate the given element (last in list) in this XML document
    requeired:
    xml_element_to_itarate AND 
    element_to_locate
    '''
    my_list = element_to_locate.split("/")
    if len(my_list) >= 1:
        locate = my_list[0]
        for elem in xml_eleemnt_to_itarate.iter():
            if elem.tag == locate:
                if len(my_list) > 1:
                    my_list.pop(0)
                elif xml_eleemnt_to_itarate.tag == my_list[0]:
                    # element_to_locate is an element.
                    return xml_eleemnt_to_itarate
                print("Debug xml_helper.locate_element: {}/".format(elem.tag))
                to_locate = ""
                for item in my_list:
                    to_locate = to_locate + "/" + item
                if to_locate.startswith("/"):
                    to_locate = to_locate[1:len(to_locate)]
                return locate_element(elem, to_locate)
    return ""


#########################################################
# Is file
# Find if the given string is a file.
# 
#########################################################
def create_xml_element(given_content):
    ''' 
    Find if the given string is a file.
    Return the XMl content on the file as XML element.
    '''
    is_a_file = os.path.isfile(given_content)
    if is_a_file:
        # Return the xml content
        conent = ET.parse(given_content).getroot()
        return conent
    elif given_content:
        try:
            return ET.fromstring(given_content)
        except:
            print("Debug xmlHelper.create_xml_element: xml_replace_with is not proper XML")
            return ""
    else:
        print("Debug xmlHelper.create_xml_element: Can't locate xml_replace_with element.")
        return ""

#########################################################
# find_and_replace
# Find element and replace on file.
# Uses: https://www.datacamp.com/community/tutorials/python-xml-elementtree
#########################################################
def find_and_replace(xml_element_to_find, xml_replace_with, xml_file_full_path):
    ''' find_and_replace: 
    Find xml_element_to_find and Replace with xml_replace_with
    '''
    tree = ET.parse(xml_file_full_path)
    root = tree.getroot()
    element = locate_element(root, xml_element_to_find)
    new_element = create_xml_element(xml_replace_with)
    if isinstance(new_element, ET.Element):
        if isinstance(element, ET.Element):
            element.clear() # Empty the element to be replaced.
            if new_element.text:
                element.text = new_element.text # Copy content of Text area.
            for item in new_element:
                element.append(item) # Add all children elements
            tree.write(xml_file_full_path)
        else:
            print("Debug xmlHelper.find_and_replace: xml_element_to_find is not a proper XML element")
    else:
        print("Debug xmlHelper.find_and_replace: xml_replace_with is not a proper XML element")

#########################################################
# find_and_add
# Find element and add on file.
# Uses: https://www.datacamp.com/community/tutorials/python-xml-elementtree
#########################################################
def find_and_add(xml_element_to_find, xml_element_to_add, index_location, xml_file_full_path):
    ''' find_and_add: 
    Find xml_element_to_find and Add the following element xml_element_to_add at location  index_location
    '''
    tree = ET.parse(xml_file_full_path)
    root = tree.getroot()
    element = locate_element(root, xml_element_to_find)
    new_element = create_xml_element(xml_element_to_add)
    if isinstance(index_location, str):
        if isinstance(new_element, ET.Element):
            if isinstance(element, ET.Element):
                element.append(new_element)
                tree.write(xml_file_full_path)
            else:
                print("Debug xmlHelper.find_and_add: xml_element_to_find is not a proper XML element")
        else:
            print("Debug xmlHelper.find_and_add: xml_element_to_add is not a proper XML element")
    else:
        try:
            index = int(index_location)
        except:
            print("Debug xmlHelper.find_and_add: index_location cannot be cast to an 'int'")
            pass
        if isinstance(new_element, ET.Element):
            if isinstance(element, ET.Element):
                element.insert(index, new_element)
                tree.write(xml_file_full_path)
            else:
                print("Debug xmlHelper.find_and_add: xml_element_to_find is not a proper XML element")
        else:
            print("Debug xmlHelper.find_and_add: xml_element_to_add is not a proper XML element")

#########################################################
# find_and_add_text
# Find element and add on file.
# Uses: https://www.datacamp.com/community/tutorials/python-xml-elementtree
#########################################################
def find_and_add_text(xml_element_to_find, given_string, xml_file_full_path):
    ''' find_and_add_test: 
    Find xml_element_to_find and Add the following given_string to the located XML element
    '''
    tree = ET.parse(xml_file_full_path)
    root = tree.getroot()
    element = locate_element(root, xml_element_to_find)
    content = ""
    if given_string.endswith(".txt"):
        with open(given_string, 'r') as file:
            content = file.read()
    else:
        content = given_string
    if isinstance(element, ET.Element):
        element.text = content
        tree.write(xml_file_full_path)
    else:
        print("Debug xmlHelper.find_and_add: xml_element_to_add is not a proper XML element")
    
#########################################################
# find_and_delete
# Find element and delete from file.
# Uses: https://www.datacamp.com/community/tutorials/python-xml-elementtree
#########################################################
def find_and_delete(xml_element_to_delete, xml_file_full_path):
    '''find_and_delete
    Given the path, locate and delete de XML element.
    '''
    tree = ET.parse(xml_file_full_path)
    root = tree.getroot()
    element_to_remove = xml_element_to_delete.split("/")[-1]
    element_parent_name = xml_element_to_delete.replace("/" + element_to_remove, "") 
    parent_element = locate_element(root, element_parent_name) # Parent XML element to remove from.
    if isinstance(parent_element, ET.Element):
        for element in parent_element:
            if (element.tag == element_to_remove) or (element.get('name') == element_to_remove):
                parent_element.remove(element)
        tree.write(xml_file_full_path)
    else:
       print("Debug xmlHelper.find_and_delete: xml_element_to_delete cannot be found") 

############################ Main ########################################

if __name__ == '__main__':
    arguments = docopt(__doc__, version='R 1.0')
    exists = os.path.isfile(arguments['<xml_file_full_path>'])
    if exists:
        if (arguments['-f'] and arguments['-r']):
            print("Debug xmlHelper: Find and replace!")
            print("Debug xmlHelper: Element to find {}".format(arguments['<xml_element_to_find>']))
            print("Debug xmlHelper: Replece with {}".format(arguments['<xml_replace_with>']))
            print("Debug xmlHelper: Document to work with {}".format(arguments['<xml_file_full_path>']))
            find_and_replace(arguments['<xml_element_to_find>'], arguments['<xml_replace_with>'],arguments['<xml_file_full_path>'])
        elif (arguments['-f'] and arguments['-a']):
            print("Debug xmlHelper: Find and add!")
            print("Debug xmlHelper: Element to find {}".format(arguments['<xml_element_to_find>']))
            print("Debug xmlHelper: Element to add {}".format(arguments['<xml_element_to_add>']))
            print("Debug xmlHelper: Element to add index {}".format(arguments['<index_location>']))
            print("Debug xmlHelper: Document to work with {}".format(arguments['<xml_file_full_path>']))
            find_and_add(arguments['<xml_element_to_find>'], arguments['<xml_element_to_add>'], arguments['<index_location>'], arguments['<xml_file_full_path>'])
        elif (arguments['-f'] and arguments['-s']):
            print("Debug xmlHelper: Find and add a text!")
            print("Debug xmlHelper: Element to find {}".format(arguments['<xml_element_to_find>']))
            print("Debug xmlHelper: txt to add {}".format(arguments['<string>']))
            print("Debug xmlHelper: Document to work with {}".format(arguments['<xml_file_full_path>']))
            find_and_add_text(arguments['<xml_element_to_find>'], arguments['<string>'], arguments['<xml_file_full_path>'])
        elif (arguments['-d']):
            print("Debug xmlHelper: Find and delete!")
            print("Debug xmlHelper: Element to delete {}".format(arguments['<xml_element_to_delete>']))
            print("Debug xmlHelper: Document to work with {}".format(arguments['<xml_file_full_path>']))
            find_and_delete(arguments['<xml_element_to_delete>'], arguments['<xml_file_full_path>'])
        else:
           pass 
    else:
       print("Debug xmlHelper: File does not exist: {}".format(arguments['<xml_file_full_path>']))	
''' 
Dependency: pip3 install docopt 
'''