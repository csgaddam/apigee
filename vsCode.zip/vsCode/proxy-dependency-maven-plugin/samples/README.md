HOW TO RUN 
-----------

using maven command directly
-----------------------------
mvn apigee-enterprise:deploy -Ptest -Dusername=<apigee edge user > -Dpassword=<apigee edge password>  -Dorg=<org name>

using script 
--------------
./deploy.sh  test <apigee edge login>
