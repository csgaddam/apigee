#call powershell -command "& {Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force}" 

#::call powershell -command Set-ExecutionPolicy "RemoteSigned" -Scope Process -Confirm:$false

#call powershell -command .\xmlScript.ps1  -swaggerPath %1 -pomPath %cd%\digiKeyApi\src\gateway\CommonProxy\pom.xml -newPath %cd%\digiKeyApi\src\gateway\%2 

#powershell -command Get_ExecutionPolicy


#& C:\Users\Chandra_Gaddam\Desktop\vsCode\xmlScript.ps1  -swaggerPath C:\Users\Chandra_Gaddam\Desktop\vsCode\swaggerDocs\PkgTypeByQty.json -pomPath C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\CommonProxy\pom.xml -newPath C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\pom


#.\xmlScript.ps1  -swaggerPath C:\Users\Chandra_Gaddam\Desktop\vsCode\swaggerDocs\PkgTypeByQty.json -pomPath C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\CommonProxy\pom.xml -newPath C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\pom


If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
{
  # Relaunch as an elevated process:
  Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
  #exit
}
# Now running elevated so launch the script:
& "C:\Users\Chandra_Gaddam\Desktop\vsCode\xmlScript.ps1" "C:\Users\Chandra_Gaddam\Desktop\vsCode\swaggerDocs\PkgTypeByQty.json" "C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\CommonProxy\pom.xml" "C:\Users\Chandra_Gaddam\Desktop\vsCode\digiKeyApi\src\gateway\pom"